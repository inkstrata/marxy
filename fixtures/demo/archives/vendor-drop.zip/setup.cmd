@echo off
copy /y plugin.dll "%APPDATA%\Tidemark\plugins\"
