#!/bin/sh
# Publishes the tide table to the harbour office's share.
set -eu
cp reading/tide-table.txt /srv/harbour/tide-table.txt
