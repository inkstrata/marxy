# Harbour survey, autumn 2026

Everything gathered at the east quay between 12 and 14 October: the gauge readings, the photographs, two recordings and
the notice that went to the harbour office.

## What is here

- `pictures/`: the quay at low water, the ribs of the old ferry, the tide chart as drawn.
- `data/`: the gauge database, the tide log, the latency table and the release.
- `recordings/`: the bell buoy, and the ferry leaving at 16:10.
- `reading/`: the essay the plates are set from, the tide table, the notice and the notebook.
- `src/`: the [indexer](src/indexer.rs) and the [script that published the table](src/publish.sh).

The crew list is packed with a password; the harbour office holds it.
