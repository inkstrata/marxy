# tidemark

tidemark keeps an index of a folder of plain-text notes. It walks the folder,
records each file's path, size, modification time and a content hash, and
writes the result to a single index file. A second run reads the index first
and only re-hashes files whose size or time changed, so a folder of a few
thousand notes is indexed again in well under a second.

The index is what makes search, backlinks and "what changed since Tuesday"
cheap. Nothing leaves the machine and the notes are never modified.

## Quick start

    cargo build --release
    tidemark index ~/notes
    tidemark changes --since 2026-10-12

See docs/config.md for the settings and docs/releases.md for what changed.
