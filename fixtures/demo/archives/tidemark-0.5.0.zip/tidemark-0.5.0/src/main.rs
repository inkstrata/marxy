use std::env;
use std::path::PathBuf;
use std::process::ExitCode;

mod index;
mod journal;

use index::Index;

const USAGE: &str = "usage: tidemark <index|changes> <folder> [--since YYYY-MM-DD]";

fn main() -> ExitCode {
    let args: Vec<String> = env::args().skip(1).collect();
    let Some(command) = args.first() else {
        eprintln!("{USAGE}");
        return ExitCode::from(2);
    };
    let root = PathBuf::from(args.get(1).map(String::as_str).unwrap_or("."));

    match command.as_str() {
        "index" => match run_index(&root) {
            Ok(count) => {
                println!("indexed {count} files under {}", root.display());
                ExitCode::SUCCESS
            }
            Err(err) => {
                eprintln!("tidemark: {err}");
                ExitCode::FAILURE
            }
        },
        "changes" => {
            let since = args
                .iter()
                .position(|a| a == "--since")
                .and_then(|i| args.get(i + 1));
            journal::print_changes(&root, since.map(String::as_str));
            ExitCode::SUCCESS
        }
        other => {
            eprintln!("unknown command {other:?}\n{USAGE}");
            ExitCode::from(2)
        }
    }
}

fn run_index(root: &PathBuf) -> std::io::Result<usize> {
    let mut index = Index::load(root)?;
    let touched = index.refresh()?;
    index.save()?;
    journal::record(root, touched)?;
    Ok(index.len())
}
