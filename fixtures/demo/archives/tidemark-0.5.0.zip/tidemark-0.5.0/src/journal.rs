use std::fs::OpenOptions;
use std::io::{self, Write};
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

pub fn record(root: &Path, touched: Vec<String>) -> io::Result<()> {
    if touched.is_empty() {
        return Ok(());
    }
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
    let mut log = OpenOptions::new()
        .create(true)
        .append(true)
        .open(root.join(".tidemark").join("journal.log"))?;
    for path in touched {
        writeln!(log, "{now}\t{path}")?;
    }
    Ok(())
}

pub fn print_changes(root: &Path, since: Option<&str>) {
    let text = std::fs::read_to_string(root.join(".tidemark").join("journal.log")).unwrap_or_default();
    let cutoff = since.unwrap_or("1970-01-01");
    for line in text.lines().filter(|l| !l.is_empty()) {
        println!("{cutoff} {line}");
    }
}
