use std::collections::BTreeMap;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use std::time::UNIX_EPOCH;

use serde::{Deserialize, Serialize};
use walkdir::WalkDir;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entry {
    pub size: u64,
    pub mtime_ns: u128,
    pub hash: String,
}

pub struct Index {
    root: PathBuf,
    entries: BTreeMap<String, Entry>,
}

impl Index {
    pub fn load(root: &Path) -> io::Result<Self> {
        let file = root.join(".tidemark").join("index.json");
        let entries = match fs::read_to_string(&file) {
            Ok(text) => serde_json::from_str(&text).unwrap_or_default(),
            Err(err) if err.kind() == io::ErrorKind::NotFound => BTreeMap::new(),
            Err(err) => return Err(err),
        };
        Ok(Index { root: root.to_path_buf(), entries })
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    // Re-hash only when size or mtime moved; returns the paths that changed.
    pub fn refresh(&mut self) -> io::Result<Vec<String>> {
        let mut touched = Vec::new();
        for item in WalkDir::new(&self.root).into_iter().filter_map(Result::ok) {
            if !item.file_type().is_file() || item.path().components().any(|c| c.as_os_str() == ".tidemark") {
                continue;
            }
            let meta = item.metadata()?;
            let rel = item.path().strip_prefix(&self.root).unwrap().to_string_lossy().replace('\\', "/");
            let mtime_ns = meta.modified()?.duration_since(UNIX_EPOCH).unwrap().as_nanos();
            let fresh = self.entries.get(&rel).map_or(true, |e| e.size != meta.len() || e.mtime_ns != mtime_ns);
            if fresh {
                let hash = blake3::hash(&fs::read(item.path())?).to_hex().to_string();
                self.entries.insert(rel.clone(), Entry { size: meta.len(), mtime_ns, hash });
                touched.push(rel);
            }
        }
        Ok(touched)
    }

    pub fn save(&self) -> io::Result<()> {
        let dir = self.root.join(".tidemark");
        fs::create_dir_all(&dir)?;
        fs::write(dir.join("index.json"), serde_json::to_string(&self.entries)?)
    }
}
