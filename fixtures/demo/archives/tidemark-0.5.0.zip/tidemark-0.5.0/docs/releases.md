# Releases

## 0.5.0

- The journal records the time of each change.
- `changes --since` accepts a date.
- Hidden folders other than `.tidemark` are indexed.

## 0.4.2

- Fixed a crash when a note was deleted during a run.
- Paths are stored with forward slashes on every platform.

## 0.4.0

- First release with the incremental refresh.
