# Configuration

tidemark reads `.tidemark/config.toml` from the folder it indexes. Every
setting is optional.

## Settings

- `ignore`: glob patterns to skip, such as `drafts/**` or `*.tmp`
- `hash`: the hash used for change detection, `blake3` by default
- `follow_links`: whether to follow symbolic links, `false` by default
- `journal`: keep a log of changed paths, `true` by default

## Example

```toml
ignore = ["drafts/**", "*.tmp"]
hash = "blake3"
follow_links = false
journal = true
```

Settings given on the command line win over the file. Unknown keys are
reported once and then ignored, so a newer config still loads in an older
build.
